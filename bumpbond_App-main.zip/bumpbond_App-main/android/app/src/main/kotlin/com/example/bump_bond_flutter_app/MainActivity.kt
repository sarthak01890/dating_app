package com.example.bump_bond_flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
